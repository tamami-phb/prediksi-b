--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.18
-- Dumped by pg_dump version 10.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.fakta DROP CONSTRAINT fakta_pkey;
ALTER TABLE ONLY public.dim_waktu DROP CONSTRAINT dim_waktu_pkey;
ALTER TABLE ONLY public.dim_staf DROP CONSTRAINT dim_staf_pkey;
ALTER TABLE ONLY public.dim_film DROP CONSTRAINT dim_film_pkey;
ALTER TABLE ONLY public.dim_customer DROP CONSTRAINT dim_customer_pkey;
DROP TABLE public.fakta;
DROP TABLE public.dim_waktu;
DROP TABLE public.dim_staf;
DROP TABLE public.dim_film;
DROP TABLE public.dim_customer;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dim_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_customer (
    id integer NOT NULL,
    kota character varying(250),
    negara character varying(250),
    nama character varying(250),
    customer_id integer
);


ALTER TABLE public.dim_customer OWNER TO postgres;

--
-- Name: dim_film; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_film (
    id integer NOT NULL,
    judul character varying(250),
    kategori character varying(250),
    aktor character varying(250),
    film_id integer
);


ALTER TABLE public.dim_film OWNER TO postgres;

--
-- Name: dim_staf; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_staf (
    id integer NOT NULL,
    nama character varying(250),
    kota character varying(250),
    negera character varying(250),
    staf_id integer
);


ALTER TABLE public.dim_staf OWNER TO postgres;

--
-- Name: dim_waktu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_waktu (
    id integer NOT NULL,
    tahun integer,
    bulan character varying,
    hari integer
);


ALTER TABLE public.dim_waktu OWNER TO postgres;

--
-- Name: fakta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fakta (
    id integer NOT NULL,
    amount numeric,
    sk_waktu integer,
    sk_film integer,
    sk_customer integer,
    sk_staf integer
);


ALTER TABLE public.fakta OWNER TO postgres;

--
-- Data for Name: dim_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_customer (id, kota, negara, nama, customer_id) FROM stdin;
\.
COPY public.dim_customer (id, kota, negara, nama, customer_id) FROM '$$PATH$$/2823.dat';

--
-- Data for Name: dim_film; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_film (id, judul, kategori, aktor, film_id) FROM stdin;
\.
COPY public.dim_film (id, judul, kategori, aktor, film_id) FROM '$$PATH$$/2821.dat';

--
-- Data for Name: dim_staf; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_staf (id, nama, kota, negera, staf_id) FROM stdin;
\.
COPY public.dim_staf (id, nama, kota, negera, staf_id) FROM '$$PATH$$/2822.dat';

--
-- Data for Name: dim_waktu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_waktu (id, tahun, bulan, hari) FROM stdin;
\.
COPY public.dim_waktu (id, tahun, bulan, hari) FROM '$$PATH$$/2820.dat';

--
-- Data for Name: fakta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fakta (id, amount, sk_waktu, sk_film, sk_customer, sk_staf) FROM stdin;
\.
COPY public.fakta (id, amount, sk_waktu, sk_film, sk_customer, sk_staf) FROM '$$PATH$$/2824.dat';

--
-- Name: dim_customer dim_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_customer
    ADD CONSTRAINT dim_customer_pkey PRIMARY KEY (id);


--
-- Name: dim_film dim_film_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_film
    ADD CONSTRAINT dim_film_pkey PRIMARY KEY (id);


--
-- Name: dim_staf dim_staf_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_staf
    ADD CONSTRAINT dim_staf_pkey PRIMARY KEY (id);


--
-- Name: dim_waktu dim_waktu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_waktu
    ADD CONSTRAINT dim_waktu_pkey PRIMARY KEY (id);


--
-- Name: fakta fakta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fakta
    ADD CONSTRAINT fakta_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

